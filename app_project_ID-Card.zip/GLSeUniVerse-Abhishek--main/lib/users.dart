String finalEmail = '';
String finalEnrollment = '';
String finalName = '';
String finaldiv = '';
String finalqr_code = '';
String finalduration = '';
String finaldepartment = '';
String finaldept_abbr = '';
String finalcourse_abbr = '';
String finalcourse_name = '';
String finalbatch_start_year = '';
String finalrole = '';
String finalprofile = '';
String finalcontact='';
String checkrole = '';

String finalqr_name = '';
String finalqr_program = '';
String finalqr_department = '';
String finalqr_role ='Not Applicable';
String finalqr_profile = '';

String qr_username = '';
String qr_role = '';
String qr_key = '';

int postindex = 0;


List<dynamic> docs = [];
List<String> items = [];
List<dynamic> posts = [];
List<String> itemsindex = [];
List<String> mainList = [];